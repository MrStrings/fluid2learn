/*
    Arquivo editado por: (file edited by:)
    Pedro Henrique Ferreira Stringhini
    RA: 156983 (Academic ID)
    
    Enquirer: descobre qual ser que o responder aponta de acordo com sua
              database de perguntas.
*/


package pt.c01interfaces.s01knowledge.s02app.actors;

import java.util.TreeMap;
import pt.c01interfaces.s01knowledge.s01base.impl.BaseConhecimento;
import pt.c01interfaces.s01knowledge.s01base.inter.IBaseConhecimento;
import pt.c01interfaces.s01knowledge.s01base.inter.IDeclaracao;
import pt.c01interfaces.s01knowledge.s01base.inter.IEnquirer;
import pt.c01interfaces.s01knowledge.s01base.inter.IObjetoConhecimento;
import pt.c01interfaces.s01knowledge.s01base.inter.IResponder;

public class Enquirer implements IEnquirer {

    IObjetoConhecimento obj;

    public Enquirer() {
    }

    @Override
    public void connect(IResponder responder) {
        IBaseConhecimento bc = new BaseConhecimento();

        String[] animais = bc.listaNomes();

        int i;
        boolean animalEsperado = false;
        String respostaEsperada, resposta;

        TreeMap<String, String> map = new TreeMap(); //Guarda perguntas feitas

        // Passa por cada animal, ateh encontrar o certo:
        for (i = 0; i < animais.length && animalEsperado == false; i++) {
            obj = bc.recuperaObjeto(animais[i]);

            IDeclaracao decl = obj.primeira();

            animalEsperado = true;
            while (decl != null && animalEsperado) {
                String pergunta = decl.getPropriedade();

                respostaEsperada = decl.getValor();

                // testa se houve resposta repetida 
                if (map.containsKey(pergunta)) {
                    resposta = map.get(pergunta);
                } else {
                    resposta = responder.ask(pergunta);
                    map.put(pergunta, resposta); // Adiciona pergunta a database
                }
                if (resposta.equalsIgnoreCase(respostaEsperada)) {
                    decl = obj.proxima();
                } else {
                    animalEsperado = false;
                }
            }
        }
        boolean acertei = responder.finalAnswer(animais[i - 1]);

        if (acertei) {
            System.out.println("Oba! Acertei!");
        } else {
            System.out.println("fuem! fuem! fuem!");
        }

    }

}
