package pt.c01interfaces.s01knowledge.s01base.inter;

public interface IDeclaracao
{
	public String getPropriedade();

	public String getValor();
	
	public String toString();
}