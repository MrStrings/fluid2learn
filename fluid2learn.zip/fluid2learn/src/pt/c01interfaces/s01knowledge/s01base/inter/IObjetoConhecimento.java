package pt.c01interfaces.s01knowledge.s01base.inter;


public interface IObjetoConhecimento
{
	public IDeclaracao primeira();

	public IDeclaracao proxima();
}