package pt.c01interfaces.s01knowledge.s01base.inter;

public interface IEnquirer
{
    public void connect(IResponder responder);
}
