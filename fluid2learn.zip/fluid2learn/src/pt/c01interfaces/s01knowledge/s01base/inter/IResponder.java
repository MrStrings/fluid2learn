package pt.c01interfaces.s01knowledge.s01base.inter;


public interface IResponder
{
    public String ask(String question);
    
    public boolean finalAnswer(String answer);
}
