package pt.base.inter;

public interface IDeclaracao
{
	public String getPropriedade();
	public String getValor();
	public String toString();
}