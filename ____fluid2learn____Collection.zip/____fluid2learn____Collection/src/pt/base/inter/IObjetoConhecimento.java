package pt.base.inter;


public interface IObjetoConhecimento
{
	public IDeclaracao primeira();
	public IDeclaracao proxima();
}