# fluid2learn_Collection
Collection of minigames designed in OOP introduction class

Contains for now two games:

-AnimalGuesser

-Maze


Project originaly forked from:
https://github.com/santanche/fluid2learn.git